import { NextRequest, NextResponse } from "next/server";
;
import { requireAdmin } from "@/lib/auth/guards";
import { logAuditEvent } from "@/lib/audit";
import { AuditAction } from "@/lib/db/enums";

/**
 * Reactivate or reissue an invitation code (admin only)
 * This clears the used_at field and optionally extends the expiry date
 */
export async function POST(req: NextRequest) {
  try {
    // Require admin authentication
    const admin = await requireAdmin();
    
    const body = await req.json();
    const { token, extendDays } = body;

    if (!token) {
      return NextResponse.json(
        { error: "Token is required" },
        { status: 400 }
      );
    }

    // Look up the invite
    let invite: {
      id: string,
      clientId: string,
      token: string,
      email: string,
      expires_at: Date;
      used_at: Date | null;
      createdAt: Date;
    } | null = null;

    try {
      const { queryRaw, update: updateInvite } = await import("@/lib/db");
      const inviteResult = await queryRaw<{
        id: string,
        clientId: string,
        token: string,
        email: string,
        expires_at: Date;
        used_at: Date | null;
        createdAt: Date;
      }>(`
        SELECT 
          id,
          "clientId",
          token,
          email,
          expires_at,
          used_at,
          "createdAt"
        FROM client_invites
        WHERE token = $1
        LIMIT 1
      `, [token]);

      if (inviteResult && inviteResult.length > 0 && inviteResult[0]) {
        invite = inviteResult[0];
      }
    } catch (sqlError: unknown) {
      const errorMessage = sqlError instanceof Error ? sqlError.message : String(sqlError);
      console.error("Reactivate invite: Raw SQL lookup failed:", errorMessage);
      
      // If raw SQL fails, return error
      return NextResponse.json(
        { error: `Failed to lookup invite: ${errorMessage}` },
        { status: 500 }
      );
    }

    if (!invite) {
      return NextResponse.json(
        { error: "Invite not found" },
        { status: 404 }
      );
    }

    // Calculate new expiry date
    const newExpiresAt = extendDays 
      ? new Date(Date.now() + extendDays * 24 * 60 * 60 * 1000)
      : new Date(Date.now() + 14 * 24 * 60 * 60 * 1000); // Default 14 days

    // Reactivate the invite (clear used_at and update expiry)
    const { update: updateInvite } = await import("@/lib/db");
    try {
      await updateInvite("client_invites", { token }, {
        usedAt: null,
        expiresAt: newExpiresAt.toISOString(),
        updatedAt: new Date().toISOString(),
      } as Record<string, unknown>);
    } catch (sqlError: unknown) {
      const errorMessage = sqlError instanceof Error ? sqlError.message : String(sqlError);
      console.error("Reactivate invite: Raw SQL update failed:", errorMessage);
      return NextResponse.json(
        { error: `Failed to reactivate invite: ${errorMessage}` },
        { status: 500 }
      );
    }

    // Audit log the reactivation
    try {
      await logAuditEvent({
        userId: admin.id,
        action: AuditAction.INVITE_REACTIVATED,
        clientId: invite.clientId,
        metadata: {
          message: `Admin ${admin.email} reactivated invite code ${token} for client ${invite.clientId}`,
        },
      });
    } catch (auditError: unknown) {
      const auditErrorMessage = auditError instanceof Error ? auditError.message : String(auditError);
      console.error("Reactivate invite: Audit logging failed:", auditErrorMessage);
      // Continue even if audit fails
    }

    return NextResponse.json({
      success: true,
      invite: {
        token: invite.token,
        email: invite.email,
        expiresAt: newExpiresAt.toISOString(),
        usedAt: null,
      },
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error reactivating invite:", errorMessage);
    return NextResponse.json(
      { error: errorMessage || "Failed to reactivate invite" },
      { status: 500 }
    );
  }
}

