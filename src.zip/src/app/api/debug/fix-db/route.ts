import { NextResponse } from "next/server";
;

export const runtime = "nodejs";

/**
 * Debug endpoint to fix database schema issues
 * Only available in development mode
 */
export async function GET() {
  // Only allow in development
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json({ error: "Not available in production" }, { status: 403 });
  }
  return await fixDatabase();
}

export async function POST() {
  // Only allow in development
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json({ error: "Not available in production" }, { status: 403 });
  }
  return await fixDatabase();
}

async function fixDatabase() {
  try {
    const results: string[] = [];

    const { queryRaw } = await import("@/lib/db");
    
    // Check if the constraint already exists
    const existingIndex = await queryRaw<Array<{
      indexname: string,
    }>>(`
      SELECT indexname 
      FROM pg_indexes 
      WHERE tablename = 'users' 
        AND indexname = 'users_clerkId_key'
    `, []);

    if (existingIndex.length > 0) {
      results.push("✅ Unique constraint 'users_clerkId_key' already exists");
    } else {
      // Create the unique constraint
      await queryRaw(`
        CREATE UNIQUE INDEX IF NOT EXISTS "users_clerkId_key" ON "users"("clerkId");
      `, []);
      results.push("✅ Created unique constraint 'users_clerkId_key' on users.clerkId");
    }

    // Verify it was created
    const verifyIndex = await queryRaw<Array<{
      indexname: string,
      indexdef: string,
    }>>(`
      SELECT indexname, indexdef
      FROM pg_indexes 
      WHERE tablename = 'users' 
        AND indexname = 'users_clerkId_key'
    `, []);

    type IndexInfo = { indexname: string; indexdef: string };
    const verifyIndexArray: IndexInfo[] = (verifyIndex || []) as unknown as IndexInfo[];
    if (verifyIndexArray.length > 0) {
      results.push(`✅ Verified: ${verifyIndexArray[0]?.indexdef || 'unknown'}`);
    } else {
      results.push("⚠️ Warning: Could not verify constraint creation");
    }

    // Also check if the column exists
    type ColumnCheck = { column_name: string; data_type: string };
    const columnCheckResult = await queryRaw<Array<ColumnCheck>>(`
      SELECT column_name, data_type
      FROM information_schema.columns
      WHERE table_schema = 'public' 
        AND table_name = 'users'
        AND column_name IN ('clerkId', 'clerk_id')
    `, []);
    const columnCheckArray: ColumnCheck[] = (columnCheckResult || []) as unknown as ColumnCheck[];

    if (columnCheckArray.length > 0) {
      results.push(`✅ Found column: ${columnCheckArray[0]?.column_name || 'unknown'} (${columnCheckArray[0]?.data_type || 'unknown'})`);
    } else {
      results.push("⚠️ Warning: Could not find clerkId or clerk_id column");
    }

    return NextResponse.json({
      ok: true,
      message: "Database fix applied",
      results,
    });
  } catch (e: unknown) {
    const err = e as { message?: string, code?: string };
    return NextResponse.json(
      {
        ok: false,
        error: "Failed to fix database",
        message: err?.message ?? String(e),
        code: err?.code,
      },
      { status: 500 }
    );
  }
}

