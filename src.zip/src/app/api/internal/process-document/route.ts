// src/app/api/internal/process-document/route.ts
// Background job for OCR, extraction, and confidence scoring
// This should be called by a queue system or cron job

import { NextRequest, NextResponse } from "next/server";
;
import { logAuditEvent } from "@/lib/audit";

/**
 * Extract safe entities from OCR text (mask SSN/ID, last4 only if needed)
 */
function extractSafeEntities(ocrText: string): Array<{
  entityType: string;
  entityValue: string;
  confidence: number;
}> {
  const entities: Array<{ entityType: string; entityValue: string; confidence: number }> = [];

  // Extract policy number (safe to show)
  const policyNumberMatch = ocrText.match(/(?:policy|policy\s*#|policy\s*number)[\s:]*([A-Z0-9\-]+)/i);
  if (policyNumberMatch) {
    entities.push({
      entityType: "policy_number",
      entityValue: policyNumberMatch[1],
      confidence: 0.8,
    });
  }

  // Extract beneficiary names (safe to show)
  const nameMatches = ocrText.match(/(?:beneficiary|beneficiaries?)[\s:]*([A-Z][a-z]+\s+[A-Z][a-z]+)/gi);
  if (nameMatches) {
    nameMatches.forEach(match => {
      const nameMatch = match.match(/([A-Z][a-z]+\s+[A-Z][a-z]+)/);
      if (nameMatch) {
        entities.push({
          entityType: "beneficiary_name",
          entityValue: nameMatch[1],
          confidence: 0.7,
        });
      }
    });
  }

  // Extract SSN last 4 only (mask full SSN)
  const ssnMatch = ocrText.match(/\b\d{3}-\d{2}-(\d{4})\b/);
  if (ssnMatch) {
    entities.push({
      entityType: "ssn_last4",
      entityValue: `****-**-${ssnMatch[1]}`,
      confidence: 0.9,
    });
  }

  return entities;
}

/**
 * Calculate confidence score based on OCR quality and extracted data
 */
function calculateConfidenceScore(
  ocrConfidence: number | null,
  extractedEntities: number
): number {
  let score = 0.5; // Base score

  if (ocrConfidence !== null) {
    score = ocrConfidence * 0.7; // OCR confidence is 70% of total
  }

  // More entities = higher confidence
  if (extractedEntities > 0) {
    score += Math.min(extractedEntities * 0.1, 0.3); // Up to 30% boost
  }

  return Math.min(score, 1.0);
}

export async function POST(req: NextRequest) {
  try {
    // Internal API - should be protected by API key or internal network
    const authHeader = req.headers.get("authorization");
    const expectedKey = process.env.INTERNAL_API_KEY;
    
    if (expectedKey && authHeader !== `Bearer ${expectedKey}`) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const body = await req.json();
    const { documentId } = body;

    if (!documentId) {
      return NextResponse.json(
        { error: "documentId is required" },
        { status: 400 }
      );
    }

    // Get document
    const { findUnique: findUniqueDoc } = await import("@/lib/db");
    
    type DocumentRecord = {
      id: string;
      clientId: string;
      fileName: string;
      classificationStatus: string;
    };
    
    const document = await findUniqueDoc<DocumentRecord>("documents", { id: documentId });
    
    if (!document) {
      return NextResponse.json(
        { error: "Document not found" },
        { status: 404 }
      );
    }
    
    // Client ID is available from document.clientId - no need to fetch separately

    if (document.classificationStatus !== "PENDING_OCR") {
      return NextResponse.json(
        { error: "Document already processed" },
        { status: 400 }
      );
    }

    // Future: Integrate OCR service (Tesseract.js, Google Cloud Vision, or AWS Textract)
    // See OCR_IMPLEMENTATION.md for implementation guide
    // For now, OCR returns empty text - document processing continues without extracted data
    
    const ocrText = ""; // Placeholder - will contain OCR results when implemented
    const ocrConfidence = 0.85; // Placeholder

    // Extract safe entities
    const entities = extractSafeEntities(ocrText);

    // Calculate confidence score
    const confidenceScore = calculateConfidenceScore(ocrConfidence, entities.length);

    // Set status based on confidence
    const classificationStatus = confidenceScore >= 0.85 ? "AUTO_ACCEPTED" : "NEEDS_REVIEW";

    // Update document
    const { update: updateDoc, create: createDb } = await import("@/lib/db");
    const { randomUUID } = await import("crypto");
    
    await updateDoc("documents", { id: document.id }, {
      ocrConfidence: ocrConfidence,
      confidenceScore: confidenceScore,
      classificationStatus: classificationStatus,
      extractedData: {
        entities: entities,
        ocrText: ocrText.substring(0, 1000), // Store first 1000 chars only
      },
      updatedAt: new Date().toISOString(),
    } as any);

    // Create document_extractions records
    for (const entity of entities) {
      await createDb("document_extractions", {
        id: randomUUID(),
        documentId: document.id,
        entityType: entity.entityType,
        entityValue: entity.entityValue,
        confidence: entity.confidence,
        createdAt: new Date().toISOString(),
      } as any);
    }

    // If beneficiaries detected, create beneficiary rows
    const beneficiaryEntities = entities.filter(e => e.entityType === "beneficiary_name");
    for (const entity of beneficiaryEntities) {
      const nameParts = entity.entityValue.split(" ");
      if (nameParts.length >= 2) {
        await createDb("beneficiaries", {
          id: randomUUID(),
          clientId: document.clientId,
          firstName: nameParts[0],
          lastName: nameParts.slice(1).join(" "),
          verificationStatus: "PENDING",
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        } as any);
      }
    }

    // Log processing
    await logAuditEvent({
      action: "OCR_COMPLETED",
      metadata: {
        message: `OCR completed for document ${document.fileName}`,
        documentId: document.id,
      },
    });

    await logAuditEvent({
      action: "EXTRACTION_COMPLETED",
      metadata: {
        message: `Extracted ${entities.length} entities from document ${document.fileName}`,
        documentId: document.id,
        entityCount: entities.length,
      },
    });

    return NextResponse.json({
      success: true,
      document: {
        id: document.id,
        classificationStatus: classificationStatus,
        confidenceScore: confidenceScore,
        entitiesExtracted: entities.length,
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error("Error processing document:", error);
    return NextResponse.json(
      { error: "Failed to process document", details: message },
      { status: 500 }
    );
  }
}

