import { NextRequest, NextResponse } from "next/server";
;
import { randomUUID } from "crypto";
import { AuditAction } from "@/lib/db/enums";
import { verifyConfirmationCode } from "../send-confirmation/route";
import { getOrCreateTestInvite } from "@/lib/test-invites";
import { lookupClientInvite } from "@/lib/invite-lookup";
import { renderToStream } from "@react-pdf/renderer";
import { ClientReceiptPDF } from "@/pdfs/ClientReceiptPDF";
import { sendClientReceiptEmail, sendAttorneyNotificationEmail } from "@/lib/email/notifications";

export const runtime = "nodejs";

// Helper functions to normalize queryRaw results
function asRows<T>(res: unknown): T[] {
  if (!res) return [];
  if (Array.isArray(res)) return res as T[];
  if (typeof res === "object" && res !== null && "rows" in res) {
    const rows = (res as { rows: unknown }).rows;
    return Array.isArray(rows) ? (rows as T[]) : [];
  }
  return [];
}

function first<T>(res: unknown): T | null {
  const rows = asRows<T>(res);
  return rows.length ? rows[0] : null;
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ token: string }> }
) {
  try {
    const { token } = await params;
    const body = await req.json();
    const { policies, beneficiaries, address } = body;
    
    // Get confirmation code from query or body
    const confirmationCode = body.confirmationCode || new URL(req.url).searchParams.get("code");
    const confirmationMethod = body.confirmationMethod || new URL(req.url).searchParams.get("method");

    // Verify confirmation code
    if (!confirmationCode || !confirmationMethod) {
      return NextResponse.json(
        { error: "Confirmation code is required" },
        { status: 400 }
      );
    }

    const isValid = await verifyConfirmationCode(token, confirmationCode, confirmationMethod);
    if (!isValid) {
      return NextResponse.json(
        { error: "Invalid or expired confirmation code" },
        { status: 400 }
      );
    }

    // Try to get or create test invite first
    let invite: Awaited<ReturnType<typeof getOrCreateTestInvite>> | Awaited<ReturnType<typeof lookupClientInvite>> | null = await getOrCreateTestInvite(token);

    // If not a test code, do normal lookup
    if (!invite) {
      invite = await lookupClientInvite(token);
    }

    if (!invite || typeof invite !== 'object' || !('clientId' in invite) || !('client' in invite)) {
      return NextResponse.json(
        { error: "Invalid token" },
        { status: 404 }
      );
    }
    
    // Extract clientId:and client with type assertion after type guard
    const typedInvite = invite as { 
      clientId: string, 
      client: { 
        firstName?: string, 
        lastName?: string, 
        email?: string, 
        phone?: string | null; 
        dateOfBirth?: Date | null;
      };
    };
    const clientId = typedInvite.clientId;
    const inviteClient = typedInvite.client;

    const { queryRaw, update: updateClient } = await import("@/lib/db");
    
    // Update address
    if (address) {
      try {
        await queryRaw(`
          UPDATE clients
          SET 
            address_line1 = $1,
            city = $2,
            state = $3,
            postal_code = $4,
            updated_at = NOW()
          WHERE id = $5
        `, [address.street || null, address.city || null, address.state || null, address.zipCode || null, clientId]);
      } catch (sqlError: unknown) {
        const sqlErrorMessage = sqlError instanceof Error ? sqlError.message : "Unknown error";
        console.error("Update client: SQL address update failed:", sqlErrorMessage);
        // Try Supabase update as fallback
        try {
          await updateClient("clients", { id: clientId }, {
            addressLine1: address.street || null,
            city: address.city || null,
            state: address.state || null,
            postalCode: address.zipCode || null,
            updatedAt: new Date().toISOString(),
          } as Record<string, unknown>);
        } catch (updateError: unknown) {
          const updateErrorMessage = updateError instanceof Error ? updateError.message : "Unknown error";
          console.error("Update client: Supabase address update also failed:", updateErrorMessage);
          // Continue - address update is not critical
        }
      }
    }

    // Update policies
    if (policies && Array.isArray(policies)) {
      try {
        const { deleteRecord, create: createPolicy } = await import("@/lib/db");
        
        // Delete existing policies
        const existingPoliciesRes = await queryRaw<Array<{ id: string }>>(`
          SELECT id FROM policies WHERE "clientId" = $1
        `, [clientId]);
        
        const existingPolicies = asRows<{ id: string }>(existingPoliciesRes);
        for (const existing of existingPolicies) {
          await deleteRecord("policies", { id: existing.id });
        }

        // Create new policies
        for (const policy of policies) {
          if (policy.insurerName && policy.policyNumber) {
            // Try to find existing insurer (lazy insurers: don't auto-create)
            let insurerId: string | null = null;
            let carrierNameRaw: string | null = null;
            
            try {
              const insurerRes = await queryRaw<Array<{ id: string }>>(`
                SELECT id FROM insurers WHERE LOWER(name) = LOWER($1) LIMIT 1
              `, [policy.insurerName]);
              
              const insurerRow = first<{ id: string }>(insurerRes);
              if (insurerRow) {
                insurerId = insurerRow.id;
              } else {
                // Insurer not found - store raw name instead (lazy insurers)
                carrierNameRaw = policy.insurerName;
              }
            } catch (insurerError: unknown) {
              const insurerErrorMessage = insurerError instanceof Error ? insurerError.message : "Unknown error";
              console.error("Update client: Insurer lookup failed:", insurerErrorMessage);
              // Store raw name as fallback
              carrierNameRaw = policy.insurerName;
            }

            // Create policy
            const policyId = randomUUID();
            const now = new Date().toISOString();
            await createPolicy("policies", {
              id: policyId,
              clientId: clientId,
              insurerId: insurerId,
              carrierNameRaw: carrierNameRaw,
              policyNumber: policy.policyNumber || null,
              policyType: policy.policyType || null,
              createdAt: now,
              updatedAt: now,
            } as Record<string, unknown>);
          }
        }
      } catch (sqlError: unknown) {
        const sqlErrorMessage = sqlError instanceof Error ? sqlError.message : "Unknown error";
        console.error("Update client: Policy update failed:", sqlErrorMessage);
      }
    }

    // Update beneficiaries
    if (beneficiaries && Array.isArray(beneficiaries)) {
      try {
        const { deleteRecord, create: createBeneficiary } = await import("@/lib/db");
        
        // Delete existing beneficiaries
        const existingBeneficiariesRes = await queryRaw<Array<{ id: string }>>(`
          SELECT id FROM beneficiaries WHERE "clientId" = $1
        `, [clientId]);
        
        const existingBeneficiaries = asRows<{ id: string }>(existingBeneficiariesRes);
        for (const existing of existingBeneficiaries) {
          await deleteRecord("beneficiaries", { id: existing.id });
        }

        // Create new beneficiaries
        for (const beneficiary of beneficiaries) {
          if (beneficiary.firstName && beneficiary.lastName) {
            const beneficiaryId = randomUUID();
            const now = new Date().toISOString();
            await createBeneficiary("beneficiaries", {
              id: beneficiaryId,
              clientId: clientId,
              firstName: beneficiary.firstName,
              lastName: beneficiary.lastName,
              relationship: beneficiary.relationship || null,
              createdAt: now,
              updatedAt: now,
            } as Record<string, unknown>);
          }
        }
      } catch (sqlError: unknown) {
        const sqlErrorMessage = sqlError instanceof Error ? sqlError.message : "Unknown error";
        console.error("Update client: Beneficiary update failed:", sqlErrorMessage);
      }
    }

    // Log audit event
    try {
      const { logAuditEvent } = await import("@/lib/audit");
      await logAuditEvent({
        action: AuditAction.CLIENT_UPDATED,
        metadata: {
          source: "update portal",
          clientId: clientId,
        },
      });
    } catch (auditError: unknown) {
      const auditErrorMessage = auditError instanceof Error ? auditError.message : "Unknown error";
      console.error("Update client: Audit logging failed:", auditErrorMessage);
      // Continue - audit is non-critical
    }

    // Generate receipt ID
    const receiptId = `REC-${clientId}-${Date.now()}`;

    // Get organization and attorney info for emails - use raw SQL first
    let organization: {
      id: string,
      name: string,
      addressLine1: string | null;
      addressLine2: string | null;
      city: string | null;
      state: string | null;
      postalCode: string | null;
      phone: string | null;
    } | null = null;
    let attorney: {
      id: string,
      email: string,
      firstName: string | null;
      lastName: string | null;
    } | null = null;
    try {
      const accessRes = await queryRaw<Array<{
        attorney_id: string,
        attorney_email: string,
        attorney_firstName: string | null;
        attorney_lastName: string | null;
        org_id: string,
        org_name: string,
        org_address_line1: string | null;
        org_address_line2: string | null;
        org_city: string | null;
        org_state: string | null;
        org_postal_code: string | null;
        org_phone: string | null;
      }>>(`
        SELECT 
          aca.attorney_id,
          u.email as attorney_email,
          u."firstName" as attorney_firstName,
          u."lastName" as attorney_lastName,
          o.id as org_id,
          o.name as org_name,
          o.address_line1 as org_address_line1,
          o.address_line2 as org_address_line2,
          o.city as org_city,
          o.state as org_state,
          o.postal_code as org_postal_code,
          o.phone as org_phone
        FROM attorney_client_access aca
        INNER JOIN users u ON u.id = aca.attorney_id
        LEFT JOIN org_members om ON om.user_id = aca.attorney_id
        LEFT JOIN organizations o ON o.id = om.organization_id
        WHERE aca."clientId" = $1 AND aca.is_active = true
        LIMIT 1
      `, [clientId]);
      
      const row = first<{
        attorney_id: string,
        attorney_email: string,
        attorney_firstName: string | null;
        attorney_lastName: string | null;
        org_id: string,
        org_name: string,
        org_address_line1: string | null;
        org_address_line2: string | null;
        org_city: string | null;
        org_state: string | null;
        org_postal_code: string | null;
        org_phone: string | null;
      }>(accessRes);
      
      if (row) {
        attorney = {
          id: row.attorney_id,
          email: row.attorney_email,
          firstName: row.attorney_firstName,
          lastName: row.attorney_lastName,
        };
        organization = {
          id: row.org_id,
          name: row.org_name,
          addressLine1: row.org_address_line1,
          addressLine2: row.org_address_line2,
          city: row.org_city,
          state: row.org_state,
          postalCode: row.org_postal_code,
          phone: row.org_phone,
        };
      }
    } catch (sqlError: unknown) {
      const sqlErrorMessage = sqlError instanceof Error ? sqlError.message : "Unknown error";
      console.error("Update client: Raw SQL access lookup failed:", sqlErrorMessage);
      // Continue without org/attorney info - emails will be skipped
    }

    // Get updated client with policies for receipt - use raw SQL
    let updatedClient: {
      id: string,
      firstName: string,
      lastName: string,
      email: string,
      phone: string | null;
      dateOfBirth: Date | null;
      createdAt: Date;
      policies?: Array<{
        id: string,
        policyNumber: string | null;
        policyType: string | null;
        insurer: {
          name: string,
          contactPhone: string | null;
          contactEmail: string | null;
        } | null;
      }>;
    } | null = null;
    try {
      const [clientRes, policiesRes] = await Promise.all([
        queryRaw<Array<{
          id: string,
          firstName: string,
          lastName: string,
          email: string,
          phone: string | null;
          dateOfBirth: Date | null;
          createdAt: Date;
        }>>(`
          SELECT id, "firstName", "lastName", email, phone, "dateOfBirth", "createdAt"
          FROM clients
          WHERE id = $1
        `, [clientId]),
        queryRaw<Array<{
          id: string,
          policy_number: string | null;
          policy_type: string | null;
          carrier_name_raw: string | null;
          insurer_name: string | null;
          insurer_contact_phone: string | null;
          insurer_contact_email: string | null;
        }>>(`
          SELECT 
            p.id,
            p.policy_number,
            p.policy_type,
            p.carrier_name_raw,
            i.name as insurer_name,
            i.contact_phone as insurer_contact_phone,
            i.contact_email as insurer_contact_email
          FROM policies p
          LEFT JOIN insurers i ON i.id = p.insurer_id
          WHERE p."clientId" = $1
        `, [clientId]),
      ]);
      
      const clientRow = first<{
        id: string,
        firstName: string,
        lastName: string,
        email: string,
        phone: string | null;
        dateOfBirth: Date | null;
        createdAt: Date;
      }>(clientRes);
      
      const policyRows = asRows<{
        id: string,
        policy_number: string | null;
        policy_type: string | null;
        carrier_name_raw: string | null;
        insurer_name: string | null;
        insurer_contact_phone: string | null;
        insurer_contact_email: string | null;
      }>(policiesRes);
      
      if (clientRow) {
        updatedClient = {
          id: clientRow.id,
          firstName: clientRow.firstName,
          lastName: clientRow.lastName,
          email: clientRow.email,
          phone: clientRow.phone,
          dateOfBirth: clientRow.dateOfBirth,
          createdAt: clientRow.createdAt,
          policies: policyRows.map(p => ({
            id: p.id,
            policyNumber: p.policy_number,
            policyType: p.policy_type,
            insurer: p.insurer_name ? {
              name: p.insurer_name,
              contactPhone: p.insurer_contact_phone,
              contactEmail: p.insurer_contact_email,
            } : null,
          })),
        };
      }
    } catch (sqlError: unknown) {
      const sqlErrorMessage = sqlError instanceof Error ? sqlError.message : "Unknown error";
      console.error("Update client: Raw SQL client/policies lookup failed:", sqlErrorMessage);
      // Fallback to invite.client data
      updatedClient = null;
    }

    // Generate receipt data
    const receiptData = {
      receiptId,
      client: {
        firstName: updatedClient?.firstName || inviteClient.firstName || "",
        lastName: updatedClient?.lastName || inviteClient.lastName || "",
        email: updatedClient?.email || inviteClient.email || "",
        phone: updatedClient?.phone || inviteClient.phone || null,
        dateOfBirth: updatedClient?.dateOfBirth || inviteClient.dateOfBirth || null,
      },
      policies: updatedClient?.policies?.map((p) => ({
        id: p.id,
        policyNumber: p.policyNumber,
        policyType: p.policyType,
        insurer: p.insurer ? {
          name: p.insurer.name,
          contactPhone: p.insurer.contactPhone,
          contactEmail: p.insurer.contactEmail,
        } : {
          name: "Unknown",
          contactPhone: null,
          contactEmail: null,
        },
      })) || [],
      organization: organization
        ? {
            name: organization.name,
            addressLine1: organization.addressLine1 ?? undefined,
            addressLine2: organization.addressLine2 ?? undefined,
            city: organization.city ?? undefined,
            state: organization.state ?? undefined,
            postalCode: organization.postalCode ?? undefined,
            phone: organization.phone ?? undefined,
          }
        : null,
      registeredAt: updatedClient?.createdAt || new Date(),
      receiptGeneratedAt: new Date(),
    };

    // Generate receipt PDF
    let receiptPdfBuffer: Buffer | null = null;
    try {
      const baseUrl = process.env.NEXT_PUBLIC_APP_URL || req.nextUrl.origin;
      const updateUrl = `${baseUrl}/qr-update/${token}`;
      
      const pdfStream = await renderToStream(
        ClientReceiptPDF({ 
          receiptData: {
            ...receiptData,
            updateUrl,
          }
        })
      );

      // Convert stream to buffer
      const maybeWeb = pdfStream as { getReader?: () => ReadableStreamDefaultReader<Uint8Array> };
      if (typeof maybeWeb?.getReader === "function") {
        const reader = maybeWeb.getReader();
        const chunks: Uint8Array[] = [];
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) chunks.push(value);
        }
        receiptPdfBuffer = Buffer.concat(chunks);
      } else {
        const nodeStream = pdfStream as NodeJS.ReadableStream;
        receiptPdfBuffer = await new Promise<Buffer>((resolve, reject) => {
          const chunks: Buffer[] = [];
          nodeStream.on("data", (c: Buffer) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
          nodeStream.on("end", () => resolve(Buffer.concat(chunks)));
          nodeStream.on("error", reject);
        });
      }
    } catch (pdfError) {
      console.error("Error generating receipt PDF:", pdfError);
      // Continue without PDF - emails will still be sent
    }

    // Send emails asynchronously (don't block response)
    const emailPromises: Promise<void>[] = [];

    // Send receipt email to client
    if (receiptPdfBuffer) {
      emailPromises.push(
        sendClientReceiptEmail({
          to: receiptData.client.email,
          clientName: `${receiptData.client.firstName} ${receiptData.client.lastName}`,
          receiptId,
          receiptPdf: receiptPdfBuffer,
          firmName: organization?.name,
        }).then(() => undefined).catch((emailError) => {
          console.error("Error sending client receipt email:", emailError);
        })
      );
    }

    // Send notification email to attorney
    if (attorney && organization) {
      const baseUrl = process.env.NEXT_PUBLIC_APP_URL || req.nextUrl.origin;
      const updateUrl = `${baseUrl}/qr-update/${token}`;
      const attorneyEmail = attorney.email || organization.phone;
      
      if (attorneyEmail && attorneyEmail.includes("@")) {
        emailPromises.push(
          sendAttorneyNotificationEmail({
            to: attorneyEmail,
            attorneyName: attorney.firstName || "Attorney",
            clientName: `${receiptData.client.firstName} ${receiptData.client.lastName}`,
            receiptId,
            policiesCount: receiptData.policies.length,
            updateUrl,
          }).then(() => undefined).catch((emailError) => {
            console.error("Error sending attorney notification email:", emailError);
          })
        );
      }
    }

    // Don't wait for emails to complete - return success immediately
    Promise.all(emailPromises).catch((error) => {
      console.error("Error sending emails:", error);
    });

    return NextResponse.json({
      success: true,
      message: "Information updated successfully",
      receiptId,
      receiptData,
    });
  } catch (error: unknown) {
    console.error("Error updating client:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 }
    );
  }
}

