import { NextRequest, NextResponse } from "next/server";
;
import { randomBytes } from "crypto";

/**
 * API endpoint to create a test invitation code
 * 
 * This is for testing purposes only.
 * 
 * Usage:
 *   POST /api/test/create-invite
 *   Body: { email: "test@example.com", firstName: "Test", lastName: "Client" }
 * 
 * Returns:
 *   {
 *     token: "generated-token",
 *     url: "http://localhost:3000/invite/generated-token",
 *     email: "test.client@example.com",
 *     clientName: "Test Client"
 *   }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const TEST_EMAIL = body.email || "test.client@example.com";
    const TEST_CLIENT_NAME = {
      firstName: body.firstName || "Test",
      lastName: body.lastName || "Client",
    };
    
    // Generate a unique token
    const TEST_TOKEN = `TEST-${randomBytes(12).toString("hex").toUpperCase()}`;

    const { findMany: findManyClients, findMany: findManyInvites, findUnique: findUniqueClient, create: createDbRecord, create: createInvite } = await import("@/lib/db");
    const { randomUUID: cryptoRandomUUID } = await import("crypto");
    
    // Check if a client with this email already exists and has an active invite
    const existingClients = await findManyClients("clients", {
      where: { email: TEST_EMAIL },
      limit: 1,
    });
    
    const existingClient = existingClients && existingClients.length > 0 ? (existingClients[0] as { id: string; firstName: string; lastName: string }) : null;
    
    if (existingClient) {
      const activeInvites = await findManyInvites("client_invites", {
        where: { clientId: existingClient.id },
        orderBy: { column: "createdAt", ascending: false },
        limit: 1,
      });
      
      const validInvites = (activeInvites || []).filter((inv: any) => {
        const expiresAt = typeof inv.expiresAt === 'string' ? new Date(inv.expiresAt) : inv.expiresAt;
        return expiresAt > new Date() && !inv.usedAt;
      });

      // If client exists with active invite, return it
      if (validInvites.length > 0) {
        const existingInvite = validInvites[0] as { token: string; email: string; expiresAt: Date | string };
      const requestUrl = req.nextUrl;
      const baseUrl = 
        process.env.NEXT_PUBLIC_APP_URL || 
        `${requestUrl.protocol}//${requestUrl.host}` ||
        "http://localhost:3000";
      const inviteUrl = `${baseUrl}/invite/${existingInvite.token}`;
      
        const expiresAtDate = typeof existingInvite.expiresAt === 'string' ? new Date(existingInvite.expiresAt) : existingInvite.expiresAt;
        return NextResponse.json({
          message: "Active test invite already exists for this email",
          token: existingInvite.token,
          url: inviteUrl,
          email: existingInvite.email,
          clientName: `${existingClient.firstName} ${existingClient.lastName}`,
          clientId: existingClient.id,
          expiresAt: expiresAtDate.toISOString(),
          inviteUrl: inviteUrl,
          inviteCodePage: `${baseUrl}/client/invite-code`,
        });
      }
    }

    // Find or create a test client
    let client = existingClient;

    if (!client) {
      const clientId = cryptoRandomUUID();
      const now = new Date().toISOString();
      client = await createDbRecord("clients", {
        id: clientId,
        firstName: TEST_CLIENT_NAME.firstName,
        lastName: TEST_CLIENT_NAME.lastName,
        email: TEST_EMAIL,
        createdAt: now,
        updatedAt: now,
      } as Record<string, unknown>) as { id: string; firstName: string; lastName: string };
    }

    // Create expiration date (14 days from now)
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 14);
    const now = new Date().toISOString();

    // Create the invite
    const invite = await createInvite("client_invites", {
      id: cryptoRandomUUID(),
      clientId: client.id,
      email: TEST_EMAIL,
      token: TEST_TOKEN,
      expiresAt: expiresAt.toISOString(),
      createdAt: now,
      updatedAt: now,
    } as Record<string, unknown>) as { token: string; email: string; expiresAt: string };

    // Get base URL from request if available, otherwise use env or default
    const requestUrl = req.nextUrl;
    const baseUrl = 
      process.env.NEXT_PUBLIC_APP_URL || 
      `${requestUrl.protocol}//${requestUrl.host}` ||
      "http://localhost:3000";

    const inviteUrl = `${baseUrl}/invite/${invite.token}`;

    return NextResponse.json({
      message: "Test invitation created successfully",
      token: invite.token,
      url: inviteUrl,
      email: invite.email,
      clientName: `${client.firstName} ${client.lastName}`,
      clientId: client.id,
      expiresAt: typeof invite.expiresAt === 'string' ? invite.expiresAt : new Date(invite.expiresAt).toISOString(),
      inviteUrl: inviteUrl,
      inviteCodePage: `${baseUrl}/client/invite-code`,
      instructions: [
        `1. Use this code: ${invite.token}`,
        `2. Visit: ${baseUrl}/client/invite-code`,
        `3. Enter the code: ${invite.token}`,
        `4. Or directly visit: ${inviteUrl}`,
      ],
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error creating test invite:", error);
    return NextResponse.json(
      { error: errorMessage || "Failed to create test invite" },
      { status: 500 }
    );
  }
}

