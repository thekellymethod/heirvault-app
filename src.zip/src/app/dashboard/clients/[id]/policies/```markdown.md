```markdown
📂 heir-vault
├── 📄 MIGRATION_SUMMARY.md
├── 📄 NEXT_STEPS.md
├── 📄 README.md
├── 📄 REMAINING_TASKS.md
├── 📄 SETUP.md
├── 📄 eslint.config.mjs
├── 📄 next.config.mjs
├── 📄 package-lock.json
├── 📄 package.json
├── 📄 postcss.config.mjs
├── 📄 sentry.edge.config.ts
├── 📄 sentry.server.config.ts
├── 📄 tsconfig.json
├── 📂 prisma/
│   ├── 📄 prisma.config.ts
│   ├── 📄 schema.prisma
│   └── 📂 migrations/
│       ├── 📂 20251206003916_init/
│       │   └── 📄 migration.sql
│       ├── 📂 20251206054415_add_client_invite/
│       │   └── 📄 migration.sql
│       ├── 📂 20251206054848_access_grant_unique/
│       │   └── 📄 migration.sql
│       ├── 📂 20251206060000_org_contact_fields/
│       │   └── 📄 migration.sql
│       ├── 📂 20251206060234_add_billing_fields/
│       │   └── 📄 migration.sql
│       ├── 📂 20251206060320_org_billing_fields/
│       │   └── 📄 migration.sql
│       ├── 📂 20251206064201_make_slug_required/
│       │   └── 📄 migration.sql
│       ├── 📂 20251206070000_audit_log_and_org_role/
│       │   └── 📄 migration.sql
│       ├── 📂 20251206095202_audit_read_actions/
│       │   └── 📄 migration.sql
│       └── 📄 migration_lock.toml
├── 📂 public/
│   ├── 📄 file.svg
│   ├── 📄 globe.svg
│   ├── 📄 next.svg
│   ├── 📄 vercel.svg
│   └── 📄 window.svg
├── 📂 supabase/
│   └── 📄 schema.sql
└── 📂 src/
    ├── 📄 instrumentation-client.ts
    ├── 📄 instrumentation.ts
    ├── 📄 middleware.ts
    ├── 📂 app/
    │   ├── 📄 favicon.ico
    │   ├── 📄 global-error.tsx
    │   ├── 📄 globals.css
    │   ├── 📄 layout.tsx
    │   ├── 📄 page.tsx
    │   ├── 📂 (auth)/
    │   │   └── 📂 role-router/
    │   │       └── 📄 page.tsx
    │   ├── 📂 api/
    │   │   ├── 📂 beneficiaries/
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 billing/
    │   │   │   └── 📂 checkout/
    │   │   │       └── 📄 route.ts
    │   │   ├── 📂 client/
    │   │   │   ├── 📂 beneficiaries/
    │   │   │   │   └── 📄 route.ts
    │   │   │   ├── 📂 insurers/
    │   │   │   │   └── 📄 route.ts
    │   │   │   ├── 📂 me/
    │   │   │   │   └── 📄 routes
    │   │   │   ├── 📂 policies/
    │   │   │   │   └── 📄 routes.ts
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 clients/
    │   │   │   ├── 📂 [id]/
    │   │   │   │   ├── 📂 invite/
    │   │   │   │   │   └── 📄 route.ts
    │   │   │   │   ├── 📂 policies/
    │   │   │   │   │   └── 📄 route.ts
    │   │   │   │   ├── 📂 summary-pdf/
    │   │   │   │   │   └── 📄 route.ts
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 dashboard/
    │   │   │   └── 📂 clients/
    │   │   │       └── 📂 [id]/
    │   │   │           └── 📂 policies/
    │   │   │               └── 📄 route.ts
    │   │   ├── 📂 debug/
    │   │   │   ├── 📂 create-user/
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📂 user-info/
    │   │   │       └── 📄 route.ts
    │   │   ├── 📂 documents/
    │   │   │   └── 📂 extract-policy/
    │   │   │       └── 📄 route.ts
    │   │   ├── 📂 insurers/
    │   │   │   ├── 📂 [id]/
    │   │   │   │   └── 📄 route.ts
    │   │   │   ├── 📂 search/
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 invites/
    │   │   │   ├── 📂 [token]/
    │   │   │   │   ├── 📂 accept/
    │   │   │   │   │   └── 📄 route.ts
    │   │   │   │   └── 📄 route.ts
    │   │   │   ├── 📂 accept/
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 me/
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 org/
    │   │   │   └── 📂 team/
    │   │   │       └── 📂 invite/
    │   │   │           └── 📄 route.ts
    │   │   ├── 📂 organizations/
    │   │   │   ├── 📂 [id]/
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 policies/
    │   │   │   ├── 📂 [id]/
    │   │   │   │   ├── 📂 beneficiaries/
    │   │   │   │   │   └── 📄 route.ts
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 policy-locator/
    │   │   │   ├── 📂 global/
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📂 search/
    │   │   │       └── 📄 route.ts
    │   │   ├── 📂 search/
    │   │   │   ├── 📂 global/
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📄 route.ts
    │   │   ├── 📂 sentry-example-api/
    │   │   ├── 📂 subscriptions/
    │   │   │   └── 📂 create-checkout/
    │   │   │       └── 📄 route.ts
    │   │   ├── 📂 team/
    │   │   │   └── 📂 [id]/
    │   │   │       └── 📄 route.ts
    │   │   ├── 📂 user/
    │   │   │   ├── 📂 check-role/
    │   │   │   │   └── 📄 route.ts
    │   │   │   └── 📂 set-role/
    │   │   │       └── 📄 route.ts
    │   │   └── 📂 webhooks/
    │   │       └── 📂 stripe/
    │   │           └── 📄 route.ts
    │   ├── 📂 attorney/
    │   │   ├── 📂 onboard/
    │   │   │   ├── 📄 layout.tsx
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 sign-in/
    │   │   │   ├── 📂 [[...sign-in]]/
    │   │   │   │   └── 📄 page.tsx
    │   │   │   └── 📂 complete/
    │   │   │       └── 📄 page.tsx
    │   │   └── 📂 sign-up/
    │   │       ├── 📂 [[...sign-up]]/
    │   │       │   └── 📄 page.tsx
    │   │       └── 📂 complete/
    │   │           └── 📄 page.tsx
    │   ├── 📂 client/
    │   │   ├── 📂 enter-invite/
    │   │   │   └── 📄 page.tsx
    │   │   └── 📂 login/
    │   │       └── 📂 [[...login]]/
    │   │           └── 📄 page.tsx
    │   ├── 📂 client-portal/
    │   │   ├── 📂 beneficiaries/
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 policies/
    │   │   │   ├── 📄 NewClientPolicyForm.tsx
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📄 layout.tsx
    │   │   └── 📄 page.tsx
    │   ├── 📂 dashboard/
    │   │   ├── 📂 _components/
    │   │   │   ├── 📄 DashboardLayout.tsx
    │   │   │   ├── 📄 DashboardWrapper.tsx
    │   │   │   └── 📄 SidebarNav.tsx
    │   │   ├── 📂 analytics/
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 billing/
    │   │   │   ├── 📄 BillingActions.tsx
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 clients/
    │   │   │   ├── 📂 [id]/
    │   │   │   │   ├── 📂 _components/
    │   │   │   │   │   └── 📄 InviteClientButton.tsx
    │   │   │   │   ├── 📂 beneficiaries/
    │   │   │   │   │   └── 📄 page.tsx
    │   │   │   │   ├── 📂 edit/
    │   │   │   │   │   └── 📄 page.tsx
    │   │   │   │   ├── 📂 policies/
    │   │   │   │   │   ├── 📂 new/
    │   │   │   │   │   │   └── 📄 page.tsx
    │   │   │   │   │   └── 📄 page.tsx
    │   │   │   │   ├── 📄 ClientActivityFeed.tsx
    │   │   │   │   └── 📄 page.tsx
    │   │   │   ├── 📂 new/
    │   │   │   │   └── 📄 page.tsx
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 global-search/
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 insurers/
    │   │   │   ├── 📂 [id]/
    │   │   │   │   └── 📂 edit/
    │   │   │   │       └── 📄 page.tsx
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 policies/
    │   │   │   └── 📂 [id]/
    │   │   │       ├── 📂 _components/
    │   │   │       │   └── 📄 policy_beneficiariesManager.tsx
    │   │   │       └── 📄 page.tsx
    │   │   ├── 📂 policy-locator/
    │   │   │   ├── 📂 global/
    │   │   │   │   └── 📄 page.tsx
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 settings/
    │   │   │   └── 📂 org/
    │   │   │       ├── 📄 OrgSettingsForm.tsx
    │   │   │       └── 📄 page.tsx
    │   │   ├── 📂 team/
    │   │   │   ├── 📄 TeamManagement.tsx
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📄 GlobalSearch.tsx
    │   │   ├── 📄 layout.tsx
    │   │   └── 📄 page.tsx
    │   ├── 📂 invite/
    │   │   └── 📂 [token]/
    │   │       ├── 📄 InvitePortal.tsx
    │   │       └── 📄 page.tsx
    │   ├── 📂 legal/
    │   │   ├── 📂 disclaimers/
    │   │   │   └── 📄 page.tsx
    │   │   ├── 📂 privacy/
    │   │   │   └── 📄 page.tsx
    │   │   └── 📂 terms/
    │   │       └── 📄 page.tsx
    │   ├── 📂 sentry-example-page/
    │   ├── 📂 sign-in/
    │   │   └── 📂 [[...sign-in]]/
    │   │       └── 📄 page.tsx
    │   ├── 📂 sign-up/
    │   │   └── 📂 [[...sign-up]]/
    │   │       └── 📄 page.tsx
    │   └── 📂 test-auth/
    │       └── 📄 page.tsx
    ├── 📂 components/
    │   ├── 📂 ui/
    │   │   └── 📄 button.tsx
    │   ├── 📄 Footer.tsx
    │   └── 📄 Logo.tsx
    ├── 📂 lib/
    │   ├── 📂 utils/
    │   │   ├── 📄 clerk.ts
    │   │   ├── 📄 invites.ts
    │   │   └── 📄 utils.ts
    │   ├── 📄 audit.ts
    │   ├── 📄 authz.ts
    │   ├── 📄 client-limits.ts
    │   ├── 📄 db.ts
    │   ├── 📄 email.ts
    │   ├── 📄 http.ts
    │   ├── 📄 logger.ts
    │   ├── 📄 plan.ts
    │   ├── 📄 prisma.ts
    │   ├── 📄 rate-limit.ts
    │   └── 📄 stripe.ts
    ├── 📂 pdfs/
    │   └── 📄 ClientRegistrySummary.tsx
    └── 📂 types/
        └── 📄 index.ts
```
