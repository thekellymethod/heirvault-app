"use client";

import Link from "next/link";
import Image from "next/image";
import { Footer } from "@/components/Footer";
import { Logo } from "@/components/Logo";
import {
  CornerOrnaments,
  DocumentStackGraphic,
  GridPaperPattern,
  HeroRegistryIllustration,
  ShieldRingGraphic,
  WorkflowStripGraphic,
} from "@/components/landing/LandingGraphics";

export default function LandingPage() {
  return (
    <main className="min-h-screen overflow-x-hidden bg-paper-50 text-slateui-800">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-slateui-200/80 bg-white/90 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-2 sm:py-3">
          <div className="flex items-center justify-between gap-6">
            <Logo size="xl" showTagline={false} className="flex-row gap-2" />

            <nav className="hidden md:flex items-center gap-7">
              <Link href="#home" className="text-sm font-medium text-slateui-800 hover:text-ink-900 transition">
                Home
              </Link>
              <Link href="#how-it-works" className="text-sm font-medium text-slateui-800 hover:text-ink-900 transition">
                How It Works
              </Link>
              <Link href="#resources" className="text-sm font-medium text-slateui-800 hover:text-ink-900 transition">
                Resources
              </Link>
              <Link href="#faq" className="text-sm font-medium text-slateui-800 hover:text-ink-900 transition">
                FAQ
              </Link>
              <Link href="#contact" className="text-sm font-medium text-slateui-800 hover:text-ink-900 transition">
                Contact
              </Link>
            </nav>

            <div className="flex items-center gap-3">
              <Link
                href="/attorney/sign-up"
                className="hidden sm:inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-semibold
                           border border-slateui-200 bg-white/70 text-ink-900 hover:bg-white transition"
              >
                For Attorneys
              </Link>

              <Link
                href="/client/invite-code"
                className="btn-primary inline-flex items-center justify-center px-4 py-2 text-sm"
              >
                Client Invitation
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="border-b border-slateui-200 bg-paper-100/80">
        <p className="mx-auto max-w-5xl px-4 py-2.5 text-center text-xs leading-snug text-slateui-600 sm:text-sm">
          <span className="font-medium text-ink-900">Policyholders:</span>{" "}
          <Link href="/submit-policy" className="text-gold-700 underline-offset-2 hover:underline">
            Submit policy documents without an account
          </Link>
          {" "}
          (upload + receipt). Attorneys and firms use sign-in for search and firm tools.
        </p>
      </div>

      {/* Hero */}
      <section id="home" className="relative overflow-hidden bg-hero-radial">
        {/* background image */}
        <div className="absolute inset-0">
          <Image
            src="/world-hv.png"
            alt="World map background"
            fill
            priority
            className="object-cover opacity-60"
            sizes="100vw"
          />
        </div>

        {/* overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/50 via-ink-900/60 to-ink-950/65" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 py-8 sm:py-12 md:py-16">
          <div className="grid items-center gap-8 md:gap-12 md:grid-cols-2">
            {/* Copy */}
            <div className="text-center md:text-left order-2 md:order-1">
              <p className="inline-flex items-center rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-paper-100/90">
                Secure policy discovery for families & estate professionals
              </p>

              <h1 className="mt-6 font-serif text-4xl md:text-6xl leading-[1.05] tracking-tight text-white">
                Find Unclaimed Life Insurance Policies Easily
              </h1>

              <p className="mt-6 text-base md:text-lg leading-relaxed text-paper-100/80 max-w-xl mx-auto md:mx-0">
                HeirVault helps locate active life insurance coverage connected to a decedent, with a secure workflow built
                for estate planning and post-loss administration.
              </p>

              <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Link href="/attorney/sign-up" className="btn-primary text-base px-7 py-3">
                  For Attorneys
                </Link>
                <Link
                  href="/client/invite-code"
                  className="inline-flex items-center justify-center rounded-xl px-7 py-3 text-base font-semibold
                             border border-white/15 bg-white/5 text-paper-50 hover:bg-white/10 transition"
                >
                  Client Invitation
                </Link>
              </div>

              <div className="mt-10 flex items-center justify-center md:justify-start gap-6 text-sm text-paper-100/70">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-gold-500" />
                  <span>Nationwide coverage</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-gold-500" />
                  <span>Secure registry model</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-gold-500" />
                  <span>Professional workflow</span>
                </div>
              </div>
            </div>

            {/* Visual */}
            <div className="relative order-1 md:order-2">
              <div className="relative z-10 mb-6 overflow-hidden rounded-3xl border border-white/15 bg-gradient-to-br from-white/12 via-white/5 to-transparent shadow-[0_24px_60px_rgba(0,0,0,0.25)] backdrop-blur-md">
                <div className="relative aspect-[4/3] w-full px-4 py-6 sm:px-6 sm:py-8">
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/10 via-transparent to-ink-950/30" />
                  <HeroRegistryIllustration className="relative z-[1] mx-auto h-full max-h-[min(260px,42vw)] w-full max-w-md" />
                  <p className="relative z-[1] mt-4 text-center text-sm font-medium text-paper-100/85">
                    Policy registry view — structured, auditable, firm-ready
                  </p>
                </div>
              </div>

              <div className="rounded-3xl border border-gold-500/25 bg-white/5 shadow-lift backdrop-blur relative z-0">
                <div className="p-6 md:p-8">
                  <div className="relative aspect-[4/3] w-full overflow-hidden rounded-2xl bg-ink-950/40">
                    <Image
                      src="/vault-hv.png"
                      alt="HeirVault secure vault"
                      fill
                      className="object-contain p-6 drop-shadow-2xl"
                      sizes="(max-width: 768px) 100vw, 50vw"
                      priority
                    />
                    <div className="absolute inset-0 ring-1 ring-white/10 rounded-2xl" />
                  </div>

                  <div className="mt-6 grid gap-3">
                    <div className="flex items-center justify-between text-sm text-paper-100/70">
                      <span>Security posture</span>
                      <span className="text-paper-50 font-semibold">Enterprise-grade</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-white/10 overflow-hidden">
                      <div className="h-full w-[82%] bg-gold-500/80" />
                    </div>
                    <p className="text-sm text-paper-100/70">
                      Designed for clarity, auditability, and authorized access—not document chaos.
                    </p>
                  </div>
                </div>
              </div>

              {/* subtle corner accent */}
              <div className="pointer-events-none absolute -top-6 -right-6 h-24 w-24 rounded-full bg-gold-500/15 blur-2xl" />
              <div className="pointer-events-none absolute -bottom-10 -left-10 h-32 w-32 rounded-full bg-blue-400/10 blur-2xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Bridge: dark hero → light content */}
      <div className="relative h-28 w-full overflow-hidden bg-gradient-to-b from-ink-950 via-paper-100/30 to-white">
        <WorkflowStripGraphic className="absolute bottom-2 left-1/2 h-16 w-[min(1100px,96%)] -translate-x-1/2 text-ink-900" />
      </div>

      {/* How It Works */}
      <section
        id="how-it-works"
        className="relative overflow-hidden bg-gradient-to-b from-white via-paper-50 to-white py-16 md:py-24"
      >
        <GridPaperPattern className="pointer-events-none absolute -right-8 top-0 h-[420px] w-[55%] max-w-xl opacity-50 md:opacity-70" />
        <DocumentStackGraphic className="pointer-events-none absolute -left-4 bottom-8 hidden h-36 w-44 opacity-80 lg:block" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center">
            <h2 className="font-display text-3xl md:text-4xl text-ink-900">
              How HeirVault Works
            </h2>
            <p className="mt-4 text-base md:text-lg text-slateui-600 max-w-2xl mx-auto">
              A clean, secure process designed to reduce delays and uncertainty when it matters most.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {/* Card 1 */}
            <div className="card p-8 text-center transition hover:-translate-y-1 hover:shadow-lift">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-paper-100 border border-slateui-200">
                <Image src="/search-hv.png" alt="Search icon" width={44} height={44} className="object-contain" />
              </div>
              <h3 className="mt-6 font-display text-xl text-ink-900">Search for a Policy</h3>
              <p className="mt-3 text-sm md:text-base text-slateui-600">
                Provide identifying details to help locate potential coverage associated with a decedent.
              </p>
            </div>

            {/* Card 2 */}
            <div className="card p-8 text-center transition hover:-translate-y-1 hover:shadow-lift">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-paper-100 border border-slateui-200">
                <Image src="/vault-hv.png" alt="Secure icon" width={44} height={44} className="object-contain" />
              </div>
              <h3 className="mt-6 font-display text-xl text-ink-900">Secure Your Claim</h3>
              <p className="mt-3 text-sm md:text-base text-slateui-600">
                Keep records organized and reduce back-and-forth during beneficiary or executor workflows.
              </p>
            </div>

            {/* Card 3 */}
            <div className="card p-8 text-center transition hover:-translate-y-1 hover:shadow-lift">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-paper-100 border border-slateui-200">
                <Image src="/folder-hv.png" alt="Folder icon" width={44} height={44} style={{ width: 'auto', height: 'auto' }} className="object-contain" />
              </div>
              <h3 className="mt-6 font-display text-xl text-ink-900">Manage Policies</h3>
              <p className="mt-3 text-sm md:text-base text-slateui-600">
                Maintain a structured record for future access and continuity across the lifecycle of an estate plan.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose — #resources for nav */}
      <section
        id="resources"
        className="relative overflow-hidden bg-gradient-to-br from-white via-paper-50 to-[#f3efe6] py-16 md:py-24"
      >
        <CornerOrnaments className="pointer-events-none absolute -right-16 -top-24 h-64 w-96 opacity-90 md:h-80 md:w-[28rem]" />
        <div className="pointer-events-none absolute inset-y-0 left-0 w-1/3 max-w-sm bg-gradient-to-r from-white to-transparent" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mx-auto mb-12 grid max-w-5xl items-center gap-10 md:grid-cols-[1fr_auto] md:gap-14">
            <div className="text-center md:text-left">
              <h2 className="font-display text-3xl md:text-4xl text-ink-900">Why Choose HeirVault?</h2>
              <p className="mt-4 text-base md:text-lg text-slateui-600 md:max-w-xl">
                Built for practical outcomes: fewer delays, cleaner records, and a workflow professionals can trust.
              </p>
            </div>
            <div className="mx-auto flex justify-center md:mx-0 md:justify-end">
              <ShieldRingGraphic className="h-36 w-36 shrink-0 opacity-95 drop-shadow-sm md:h-44 md:w-44" />
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            <div className="card p-8 transition hover:-translate-y-1 hover:shadow-lift">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-slateui-200 bg-paper-100">
                  <Image src="/service-hv.png" alt="Service" width={30} height={30} />
                </div>
                <h3 className="font-display text-xl text-ink-900">Comprehensive Service</h3>
              </div>
              <p className="mt-4 text-slateui-600">
                A structured approach to organizing and maintaining life insurance-related records across estate workflows.
              </p>
            </div>

            <div className="card p-8 transition hover:-translate-y-1 hover:shadow-lift">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-slateui-200 bg-paper-100">
                  <Image src="/trust-hv.png" alt="Trust" width={30} height={30} />
                </div>
                <h3 className="font-display text-xl text-ink-900">Secure & Trusted</h3>
              </div>
              <p className="mt-4 text-slateui-600">
                Privacy-forward design with controlled access patterns suited to sensitive estate and beneficiary contexts.
              </p>
            </div>

            <div className="card p-8 transition hover:-translate-y-1 hover:shadow-lift">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-slateui-200 bg-paper-100">
                  <Image src="/world-hv.png" alt="Nationwide" width={30} height={30} />
                </div>
                <h3 className="font-display text-xl text-ink-900">Nationwide Coverage</h3>
              </div>
              <p className="mt-4 text-slateui-600">
                Designed to support nationwide discovery workflows and consistent record handling across jurisdictions.
              </p>
            </div>
          </div>

          <div className="mt-12 flex flex-col justify-center gap-4 sm:flex-row">
            <Link href="/attorney/sign-up" className="btn-primary px-8 py-3 text-base">
              For Attorneys
            </Link>
            <Link href="/client/invite-code" className="btn-secondary px-8 py-3 text-base">
              Client Invitation
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section
        id="faq"
        className="relative overflow-hidden bg-gradient-to-b from-paper-50 via-white to-paper-50 py-16 md:py-24"
      >
        <GridPaperPattern className="pointer-events-none absolute inset-0 opacity-[0.35]" />
        <div className="relative z-10 mx-auto max-w-4xl px-4 sm:px-6">
          <div className="text-center">
            <h2 className="font-display text-3xl md:text-4xl text-ink-900">Frequently Asked Questions</h2>
            <p className="mt-4 text-base md:text-lg text-slateui-600">
              Common questions about HeirVault and how it works.
            </p>
          </div>

          <div className="mt-12 space-y-6">
            <div className="card p-6">
              <h3 className="font-display text-xl text-ink-900">What is HeirVault?</h3>
              <p className="mt-3 text-slateui-600">
                HeirVault is a secure, private registry that helps locate unclaimed life insurance policies. 
                It&apos;s designed for estate professionals and families to maintain organized records of life insurance 
                coverage and beneficiary information.
              </p>
            </div>

            <div className="card p-6">
              <h3 className="font-display text-xl text-ink-900">Who can use HeirVault?</h3>
              <p className="mt-3 text-slateui-600">
                HeirVault is primarily designed for attorneys and estate planning professionals. Clients can be 
                invited by their attorney to register their policy information securely.
              </p>
            </div>

            <div className="card p-6">
              <h3 className="font-display text-xl text-ink-900">Is HeirVault affiliated with insurance companies?</h3>
              <p className="mt-3 text-slateui-600">
                No. HeirVault is a private, voluntary registry that is not affiliated with insurers or regulators. 
                Participation is voluntary and not required by law.
              </p>
            </div>

            <div className="card p-6">
              <h3 className="font-display text-xl text-ink-900">How secure is my information?</h3>
              <p className="mt-3 text-slateui-600">
                HeirVault uses enterprise-grade security measures to protect your data. Access is controlled 
                and all searches are logged for audit and compliance purposes. Policy amounts are not stored.
              </p>
            </div>

            <div className="card p-6">
              <h3 className="font-display text-xl text-ink-900">What information do I need to search for a policy?</h3>
              <p className="mt-3 text-slateui-600">
                To search for policies, you&apos;ll need basic identifying information such as the decedent&apos;s name, 
                date of birth, and Social Security number. For global searches and exports, a certified death 
                certificate is required.
              </p>
            </div>

            <div className="card p-6">
              <h3 className="font-display text-xl text-ink-900">How do clients register their policies?</h3>
              <p className="mt-3 text-slateui-600">
                Attorneys can generate an invitation code for their clients. Clients use this code to access 
                the registration portal, where they can upload the first page of their policy. Once uploaded, 
                the information is automatically added to the registry and the client receives a confirmation receipt.
              </p>
            </div>

            <div className="card p-6">
              <h3 className="font-display text-xl text-ink-900">Can I make changes to my registered information?</h3>
              <p className="mt-3 text-slateui-600">
                Yes. If you need to update your policy information, you can fill out the change request form 
                on your receipt or upload a new policy page through the client portal.
              </p>
            </div>

            <div className="card p-6">
              <h3 className="font-display text-xl text-ink-900">Is there a cost to use HeirVault?</h3>
              <p className="mt-3 text-slateui-600">
                Please contact us for pricing information. We offer plans for solo practitioners, small firms, 
                and enterprise organizations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section
        id="contact"
        className="relative overflow-hidden bg-gradient-to-b from-white via-paper-100 to-[#ebe4d4] py-20 md:py-28"
      >
        <DocumentStackGraphic className="pointer-events-none absolute -left-6 bottom-0 h-40 w-48 opacity-40 md:h-48 md:w-56" />
        <div className="pointer-events-none absolute -right-20 top-1/2 h-72 w-72 -translate-y-1/2 rounded-full bg-gold-500/10 blur-3xl" />
        <div className="relative z-10 mx-auto max-w-4xl px-4 sm:px-6 text-center">
          <h2 className="font-display text-3xl md:text-4xl text-ink-900">Have More Questions?</h2>
          <p className="mt-4 text-base md:text-lg text-slateui-600">
            Contact us for more information about HeirVault and how it can help your practice.
          </p>
          <div className="mt-8">
            <Link href="/attorney/sign-up" className="btn-primary px-8 py-3 text-base">
              Get Started Today
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}

