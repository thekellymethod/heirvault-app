"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { Logo } from "@/components/Logo";
import { Footer } from "@/components/Footer";
import {
  CornerOrnaments,
  DarkGridPattern,
  HeroRegistryIllustration,
  ShieldRingOnDark,
  WorkflowStripOnDark,
} from "@/components/landing/LandingGraphics";

const border = "border-hv-border";

function PrimaryCta({ href, children, className = "" }: { href: string; children: ReactNode; className?: string }) {
  return (
    <Link href={href} className={`btn-primary text-sm font-semibold ${className}`}>
      {children}
    </Link>
  );
}

function SecondaryCta({ href, children, className = "" }: { href: string; children: ReactNode; className?: string }) {
  return (
    <Link
      href={href}
      className={`inline-flex items-center justify-center rounded-xl ${border} bg-transparent px-6 py-3 text-sm font-medium text-hv-text-secondary transition hover:bg-white/[0.04] hover:text-hv-text ${className}`}
    >
      {children}
    </Link>
  );
}

export default function HomePage() {
  return (
    <main className="min-h-screen bg-hv-bg text-hv-text antialiased">
      <div className="pointer-events-none fixed inset-0 -z-10 hv-hero-bg" />
      <div
        className="pointer-events-none fixed inset-0 -z-10 opacity-[0.22] [background-image:linear-gradient(to_right,rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.03)_1px,transparent_1px)] [background-size:64px_64px]"
        aria-hidden
      />

      {/* Header — sparse, premium */}
      <header className="sticky top-0 z-20 border-b border-hv-border bg-hv-bg/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-4">
          <Link href="/" className="flex min-w-0 items-center gap-3">
            <Logo size="lg" variant="icon-only" />
            <div className="min-w-0 leading-tight">
              <div className="font-display text-sm font-semibold tracking-wide text-hv-text">HeirVault</div>
              <div className="hv-small">Life insurance policy registry</div>
            </div>
          </Link>

          <nav className="hidden items-center gap-8 text-[13px] font-medium text-hv-text-secondary md:flex">
            <a href="#how" className="transition hover:text-hv-text">
              How it works
            </a>
            <a href="#proof" className="transition hover:text-hv-text">
              Sample output
            </a>
            <a href="#pricing" className="transition hover:text-hv-text">
              Pricing
            </a>
            <a href="#security" className="transition hover:text-hv-text">
              Security
            </a>
          </nav>

          <div className="flex shrink-0 items-center gap-3">
            <Link
              href="/attorney/sign-in"
              className="hidden rounded-xl border border-white/15 px-4 py-2 text-sm text-hv-text-secondary transition hover:bg-white/[0.04] md:inline-flex"
            >
              Log in
            </Link>
            <PrimaryCta href="/start" className="!px-4 !py-2">
              Start free
            </PrimaryCta>
          </div>
        </div>
      </header>

      {/* Single quiet line — audience + policyholder path */}
      <div className={`border-b ${border} bg-hv-bg-soft/40`}>
        <p className="mx-auto max-w-6xl px-6 py-3 text-left text-[13px] leading-snug text-hv-text-muted md:text-center">
          <span className="text-hv-text-secondary">For estate attorneys, probate administrators, and firm staff.</span>{" "}
          <span className="text-hv-text-muted">Policyholders:</span>{" "}
          <Link href="/submit-policy" className="font-medium text-hv-accent underline-offset-2 hover:underline">
            Submit policy documents
          </Link>{" "}
          <span className="text-hv-text-muted">(no sign-in, confirmation receipt). Firm tools require an account.</span>
        </p>
      </div>

      {/* Hero */}
      <section className="relative overflow-hidden px-6 pb-20 pt-16 md:pb-28 md:pt-20">
        <div className="pointer-events-none absolute -right-32 top-0 h-48 w-[22rem] opacity-[0.14] md:h-64 md:opacity-[0.18]">
          <CornerOrnaments className="h-full w-full" />
        </div>

        <div className="relative z-10 mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(280px,420px)] lg:gap-16">
          <div className="text-left">
            <h1 className="hv-hero-title max-w-[20ch]">
              A life insurance policy registry built for estates and probate.
            </h1>
            <p className="mt-8 max-w-lg hv-body">
              Track, verify, and document policies per estate—without chasing carriers.
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-3">
              <PrimaryCta href="/start">Create your first policy registry</PrimaryCta>
              <SecondaryCta href="#how">See how it works</SecondaryCta>
            </div>
            <p className="mt-10 max-w-lg text-[13px] leading-relaxed text-hv-text-muted">
              Nationwide intake · structured records · audit-oriented workflow
            </p>
          </div>

          <div className="relative mx-auto w-full max-w-md lg:mx-0 lg:max-w-none">
            <div className={`rounded-xl ${border} bg-hv-surface/90 p-6 md:p-8`}>
              <HeroRegistryIllustration className="mx-auto h-auto w-full max-w-sm opacity-[0.92]" />
              <p className="mt-5 text-center hv-small">Registry view — structured, auditable, firm-ready</p>
            </div>
          </div>
        </div>
      </section>

      {/* Divider — workflow strip, subdued */}
      <div className="relative h-11 w-full overflow-hidden border-t border-hv-border bg-hv-bg">
        <WorkflowStripOnDark className="absolute bottom-1 left-1/2 h-9 w-[min(880px,92%)] -translate-x-1/2 opacity-[0.55]" />
      </div>

      {/* Why HeirVault exists */}
      <section className="relative border-t border-hv-border bg-hv-bg-soft py-20 md:py-28">
        <DarkGridPattern className="pointer-events-none absolute -right-16 top-0 h-[min(100%,480px)] w-[min(52%,380px)] opacity-[0.22]" />
        <div className="relative z-10 mx-auto max-w-6xl px-6">
          <h2 className="hv-h2 hv-prose">Why HeirVault exists</h2>
          <p className="hv-prose mt-6 hv-body">Life insurance policies are often:</p>
          <ul className="hv-prose mt-5 space-y-2.5 text-left text-hv-text-secondary">
            <ListItem>partially known,</ListItem>
            <ListItem>undocumented,</ListItem>
            <ListItem>scattered across inboxes and folders,</ListItem>
            <ListItem>or discovered too late.</ListItem>
          </ul>
          <p className="hv-prose mt-8 hv-body">
            Firms lose time to carrier chase. Families lack a single picture of what exists. Proof ends up buried in
            clutter.
          </p>
          <aside className="hv-prose mt-10 border-l-2 border-hv-accent pl-5 [background:rgba(212,160,23,0.12)] py-4 pr-5">
            <p className="text-left text-base leading-relaxed text-hv-text">
              <span className="font-medium text-hv-accent">HeirVault addresses one problem:</span> what policies exist,
              what is verified, and what is still missing—<strong className="font-semibold text-hv-text">per estate</strong>.
            </p>
          </aside>
        </div>
      </section>

      {/* Structured registry */}
      <section className="relative border-t border-hv-border bg-hv-bg py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="hv-h2 max-w-[36rem] text-left">A structured policy registry — per estate</h2>
          <p className="hv-prose mt-6 max-w-[36rem] text-left hv-body">
            HeirVault is not a generic document vault. It is a{" "}
            <strong className="font-semibold text-hv-accent">policy-first registry</strong> that treats life insurance as a
            tracked matter record.
          </p>

          <div className="mt-10 grid gap-5 md:grid-cols-2 md:items-stretch">
            <SurfaceCard className="flex flex-col p-6 md:p-8">
              <h3 className="hv-h3 mb-5">Each estate gets an auditable registry</h3>
              <ul className="space-y-2.5 text-left text-sm leading-relaxed text-hv-text-secondary">
                <ListItemMuted>Carrier</ListItemMuted>
                <ListItemMuted>Policy number</ListItemMuted>
                <ListItemMuted>Insured party</ListItemMuted>
                <ListItemMuted>Beneficiaries</ListItemMuted>
                <ListItemMuted>Status (unknown, requested, verified, resolved)</ListItemMuted>
                <ListItemMuted>Supporting documents</ListItemMuted>
              </ul>
            </SurfaceCard>
            <SurfaceCard className="flex flex-col p-6 md:p-8">
              <h3 className="hv-h3 mb-5 text-hv-text">One system of record</h3>
              <p className="text-left text-sm leading-relaxed text-hv-text-secondary">
                The registry stays the center of gravity. Documents, uploads, and exports exist to support the policy
                record—not the reverse.
              </p>
            </SurfaceCard>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="relative border-t border-hv-border bg-hv-bg-soft py-20 md:py-28">
        <DarkGridPattern className="pointer-events-none absolute -left-8 bottom-0 h-64 w-1/2 max-w-sm opacity-[0.18]" />
        <div className="relative z-10 mx-auto max-w-6xl px-6">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-hv-text-muted">Workflow</p>
          <h2 className="hv-h2 mt-3 text-left">How it works</h2>
          <p className="mt-4 max-w-xl text-left hv-body">The same sequence applies to every estate.</p>

          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Step n="01" title="Create an estate registry" desc="Open a registry and log known or suspected policies." />
            <Step n="02" title="Track verification status" desc="Update status as carrier responses and documents arrive." />
            <Step n="03" title="Collect proof" desc="Attach documents and correspondence to the policy record." />
            <Step n="04" title="Export a summary" desc="Generate a Policy Registry Summary PDF for files or review." />
          </div>
        </div>
      </section>

      {/* Feature cards — supporting */}
      <section className="relative border-t border-hv-border bg-hv-bg py-20 md:py-28">
        <div className="mx-auto grid max-w-6xl gap-4 px-6 md:grid-cols-3 md:gap-5">
          <Feature
            title="Secure document vault"
            desc="Files attach to policies, with time-limited access and logging. The registry remains authoritative."
          />
          <Feature
            title="Client upload links"
            desc="Request documents without managing accounts. Uploads land on the correct policy record."
          />
          <Feature
            title="Policy Registry Summary"
            desc="A structured PDF of policies, status, and attachments—suitable for circulation or internal review."
          />
        </div>
      </section>

      {/* Sample output — proof */}
      <section id="proof" className="relative border-t border-hv-border bg-hv-bg-soft py-20 md:py-28">
        <div className="relative z-10 mx-auto max-w-6xl px-6">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-hv-text-muted">Deliverable</p>
          <h2 className="hv-h2 mt-3 max-w-2xl text-left">See what you get</h2>
          <p className="mt-4 max-w-xl text-left hv-body">
            The Policy Registry Summary PDF your firm generates for each estate—structured for filings, clients, or
            internal review.
          </p>

          <div className={`mt-10 rounded-xl ${border} bg-hv-surface p-6 md:p-10`}>
            <div className="flex flex-col gap-4 border-b border-white/[0.08] pb-8 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <div className="font-display text-lg font-medium text-hv-text">Sample Policy Registry Summary</div>
                <div className="mt-1 hv-small">Redacted example — structure and format only</div>
              </div>
              <span className="inline-flex w-fit rounded-md border border-white/12 bg-hv-bg/80 px-2.5 py-1 text-[11px] font-medium uppercase tracking-wide text-hv-text-muted">
                Sample
              </span>
            </div>

            <div className="mt-8 space-y-3 rounded-xl border border-hv-border bg-hv-bg/50 p-5 text-sm text-hv-text-secondary md:p-6">
              <Row label="Estate / matter:" value="Sample Estate of J. Doe" />
              <Row label="Prepared for:" value="Sample Firm, PLLC" />
              <Row label="Policies listed:" value="3 (1 verified, 2 pending)" />
              <Row label="Format:" value="2-page PDF with registry table and notes" />
            </div>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-start sm:gap-4">
              <a
                href="/api/policy-registry-summary/sample"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary inline-flex flex-1 items-center justify-center text-sm sm:flex-none sm:px-8"
              >
                View sample PDF
              </a>
              <a
                href="/api/policy-registry-summary/sample"
                download
                className="inline-flex flex-1 items-center justify-center rounded-xl border border-white/18 px-6 py-3 text-sm font-medium text-hv-text transition hover:bg-white/[0.05] sm:flex-none"
              >
                Download
              </a>
            </div>
            <p className="mt-6 text-left text-xs text-hv-text-muted">Generated from your registry in seconds.</p>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section
        id="pricing"
        className="relative border-t border-hv-border bg-hv-bg py-20 md:py-28"
      >
        <DarkGridPattern className="pointer-events-none absolute right-0 top-20 h-80 w-1/2 max-w-md opacity-[0.14]" />
        <div className="relative z-10 mx-auto max-w-6xl px-6">
          <h2 className="hv-h2 text-left">Pricing</h2>
          <p className="mt-4 max-w-xl text-left hv-body">Based on active estates, not seat count.</p>

          <div className={`mx-auto mt-10 max-w-3xl rounded-xl ${border} bg-hv-surface p-6 md:p-10`}>
            <div className="border-b border-white/[0.08] pb-8">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-hv-text-muted">Registry base</p>
              <div className="mt-3 flex flex-wrap items-baseline gap-2">
                <span className="font-display text-5xl font-semibold tracking-tight text-hv-text md:text-6xl">$39</span>
                <span className="text-lg text-hv-text-secondary">/ month per firm</span>
              </div>
            </div>

            <div className="py-8">
              <p className="mb-5 text-[11px] font-semibold uppercase tracking-[0.18em] text-hv-text-muted">Included</p>
              <ul className="space-y-3 text-left text-sm leading-relaxed text-hv-text-secondary">
                <PricingItem>
                  Up to <strong className="font-medium text-hv-text">5 active policy registries</strong> (estates)
                </PricingItem>
                <PricingItem>Unlimited policies per registry</PricingItem>
                <PricingItem>Unlimited policy-attached documents</PricingItem>
                <PricingItem>Policy status tracking</PricingItem>
                <PricingItem>Policy Registry Summary export (PDF)</PricingItem>
                <PricingItem>Client upload link per registry</PricingItem>
                <PricingItem>1 admin + 2 staff users</PricingItem>
                <PricingItem>Secure, time-limited file access</PricingItem>
                <PricingItem>Audit logging for uploads and exports</PricingItem>
              </ul>
            </div>

            <div className="space-y-0 border-t border-white/[0.08] pt-8">
              <p className="mb-4 text-[11px] font-semibold uppercase tracking-[0.18em] text-hv-text-muted">Add-ons</p>
              <div className="flex flex-col gap-1 border-b border-white/[0.06] py-4 sm:flex-row sm:items-baseline sm:justify-between">
                <span className="text-hv-text-secondary">Additional active registries</span>
                <span className="font-display text-xl font-semibold tabular-nums text-hv-text">$8 / registry / mo</span>
              </div>
              <p className="hv-small pb-4">Closed estates may be archived read-only.</p>
              <div className="flex flex-col gap-1 py-4 sm:flex-row sm:items-baseline sm:justify-between">
                <span className="text-hv-text-secondary">Additional users</span>
                <span className="font-display text-xl font-semibold tabular-nums text-hv-text">$10 / user / mo</span>
              </div>
            </div>

            <div className="mt-8 border-t border-white/[0.08] pt-8">
              <p className="mb-6 text-sm text-hv-text-secondary">
                No storage caps on included use. No long-term lock-in. Fees are predictable.
              </p>
              <PrimaryCta href="/start" className="w-full justify-center sm:w-auto">
                Create your first registry
              </PrimaryCta>
            </div>
          </div>
        </div>
      </section>

      {/* Security */}
      <section id="security" className="border-t border-hv-border bg-hv-bg-soft py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-6">
          <div className="flex max-w-4xl flex-col gap-10 md:flex-row md:items-start md:gap-14">
            <div className="min-w-0 flex-1">
              <h2 className="hv-h2">Security and trust</h2>
              <p className="mt-5 hv-body">Built for professional responsibility—not slogans.</p>
              <ul className="mt-6 space-y-2.5 text-left text-sm leading-relaxed text-hv-text-secondary">
                <ListItemMuted>Firm-level tenant isolation</ListItemMuted>
                <ListItemMuted>Role-based access</ListItemMuted>
                <ListItemMuted>Time-limited file access</ListItemMuted>
                <ListItemMuted>Action logging for key events</ListItemMuted>
              </ul>
              <p className="mt-8 text-sm italic leading-relaxed text-hv-text-muted">
                Security is structural: access boundaries and traceability first.
              </p>
            </div>
            <div className="mx-auto shrink-0 md:mx-0 md:pt-1">
              <ShieldRingOnDark className="h-24 w-24 opacity-90 md:h-28 md:w-28" />
            </div>
          </div>
        </div>
      </section>

      {/* Who it&apos;s for */}
      <section className="relative overflow-hidden border-t border-hv-border bg-hv-bg py-20 md:py-28">
        <DarkGridPattern className="pointer-events-none absolute inset-0 opacity-[0.12]" />
        <div className="relative z-10 mx-auto max-w-6xl px-6">
          <h2 className="hv-h2 text-left">Who it&apos;s for</h2>
          <p className="mt-4 max-w-xl text-left hv-body">Built for:</p>
          <div className="mt-10 grid gap-10 md:grid-cols-3 md:gap-12">
            <div>
              <p className="font-display text-base font-medium text-hv-text">Probate and estate attorneys</p>
              <p className="mt-2 text-sm leading-relaxed text-hv-text-secondary">
                Matter-centric records with a trail suitable for professional standards.
              </p>
            </div>
            <div>
              <p className="font-display text-base font-medium text-hv-text">Estate administration</p>
              <p className="mt-2 text-sm leading-relaxed text-hv-text-secondary">
                One registry per estate instead of scattered notes and attachments.
              </p>
            </div>
            <div>
              <p className="font-display text-base font-medium text-hv-text">Firm staff</p>
              <p className="mt-2 text-sm leading-relaxed text-hv-text-secondary">
                Clear view of verified, pending, and unknown—without inbox archaeology.
              </p>
            </div>
          </div>
          <p className="mt-12 max-w-xl text-left text-sm text-hv-text-muted">
            If policy visibility is a recurring problem, HeirVault fits.
          </p>
        </div>
      </section>

      {/* Final CTA */}
      <section className="border-t border-hv-border bg-hv-bg px-6 py-20 md:py-28">
        <div
          className={`hv-cta-ambience relative mx-auto max-w-3xl overflow-hidden rounded-xl border border-white/[0.1] bg-gradient-to-b from-hv-surface to-hv-bg px-8 py-14 text-center md:px-12 md:py-16`}
        >
          <WorkflowStripOnDark className="pointer-events-none absolute left-1/2 top-4 h-8 w-[min(720px,88%)] -translate-x-1/2 opacity-[0.35]" />
          <div className="relative mx-auto max-w-lg pt-6">
            <h3 className="font-display text-2xl font-semibold tracking-tight text-hv-text md:text-[1.75rem] md:leading-snug">
              Stop losing time to unstructured policy information.
            </h3>
            <p className="mt-5 text-base leading-relaxed text-hv-text-secondary">
              A registry that shows what exists—and what remains to be verified.
            </p>
            <div className="mt-8 flex justify-center">
              <PrimaryCta href="/start">Create your first policy registry</PrimaryCta>
            </div>
            <p className="mt-5 text-sm text-hv-text-muted">No credit card required for initial access.</p>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}

function SurfaceCard({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-xl border border-hv-border bg-hv-surface ${className}`}>{children}</div>
  );
}

function ListItem({ children }: { children: ReactNode }) {
  return (
    <li className="flex gap-3 pl-0.5">
      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-hv-text-muted" aria-hidden />
      <span>{children}</span>
    </li>
  );
}

function ListItemMuted({ children }: { children: ReactNode }) {
  return (
    <li className="flex gap-3">
      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-white/30" aria-hidden />
      <span>{children}</span>
    </li>
  );
}

function PricingItem({ children }: { children: ReactNode }) {
  return (
    <li className="flex gap-3">
      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-hv-text-muted" aria-hidden />
      <span>{children}</span>
    </li>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col justify-between gap-1 border-b border-white/[0.05] py-2 last:border-0 sm:flex-row sm:items-center">
      <span className="text-hv-text-muted">{label}</span>
      <span className="font-medium text-hv-text sm:text-right">{value}</span>
    </div>
  );
}

function Step({ n, title, desc }: { n: string; title: string; desc: string }) {
  return (
    <div className={`rounded-xl ${border} bg-hv-surface p-4 md:p-5`}>
      <div className="mb-3 font-mono text-[10px] font-medium tabular-nums text-hv-text-muted">{n}</div>
      <div className="font-display text-[15px] font-medium leading-snug text-hv-text">{title}</div>
      <div className="mt-2 text-[13px] leading-snug text-hv-text-secondary">{desc}</div>
    </div>
  );
}

function Feature({ title, desc }: { title: string; desc: string }) {
  return (
    <div className={`rounded-xl ${border} bg-hv-surface p-5 md:p-6`}>
      <h3 className="font-display text-[1.0625rem] font-medium leading-snug text-hv-text">{title}</h3>
      <p className="mt-3 text-left text-[13px] leading-relaxed text-hv-text-secondary">{desc}</p>
    </div>
  );
}
