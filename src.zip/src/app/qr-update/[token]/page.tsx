import { QRUpdateForm } from "./_components/QRUpdateForm";
import Link from "next/link";
import { QrCode } from "lucide-react";
import { Logo } from "@/components/Logo";
import { getOrCreateTestInvite } from "@/lib/test-invites";
import { lookupClientInvite } from "@/lib/invite-lookup";
import { redirect } from "next/navigation";

interface Props {
  params: Promise<{ token: string }>;
}

/**
 * QR Code Re-Submission / Update Page
 * 
 * This page allows policyholders to update their information by scanning
 * the QR code from their receipt. Each update creates a new version entry,
 * preserving the historical chain rather than overwriting data.
 * 
 * This page is accessible outside the system and doesn't require authentication.
 */
export default async function QRUpdatePage({ params }: Props) {
  const { token } = await params;

  // Try to get or create test invite first
  let invite: Awaited<ReturnType<typeof getOrCreateTestInvite>> | Awaited<ReturnType<typeof lookupClientInvite>> | null = await getOrCreateTestInvite(token);

  // If not a test code, do normal lookup
  if (!invite) {
    invite = await lookupClientInvite(token);
  }

  if (!invite) {
    redirect("/error?type=invalid_qr");
  }

  // Type guard to ensure invite has clientId
  if (typeof invite !== "object" || invite === null || !("clientId" in invite)) {
    redirect("/error?type=invalid_qr");
  }

  const clientId = invite.clientId as string;

  // Get current client data with policies and beneficiaries
  const { queryRaw } = await import("@/lib/db");

  type ClientRow = {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string | null;
    dateOfBirth: Date | null;
    address_line1: string | null;
    address_line2: string | null;
    city: string | null;
    state: string | null;
    postal_code: string | null;
    country: string | null;
  };

  const clientData = await queryRaw<ClientRow>(`
    SELECT 
      id, "firstName", "lastName", email, phone, "dateOfBirth",
      address_line1, address_line2, city, state, postal_code, country
    FROM clients
    WHERE id = $1
    LIMIT 1
  `, [clientId]);

  if (!clientData || clientData.length === 0) {
    redirect("/error?type=not_found");
  }

  const client = clientData[0];

  // Get current policies
  type PolicyRow = {
    id: string;
    policy_number: string | null;
    policy_type: string | null;
    insurer_name: string;
  };

  const policies = await queryRaw<PolicyRow>(`
    SELECT 
      p.id,
      p.policy_number,
      p.policy_type,
      i.name as insurer_name
    FROM policies p
    INNER JOIN insurers i ON i.id = p.insurer_id
    WHERE p."clientId" = $1
    ORDER BY p."createdAt" DESC
  `, [clientId]);

  // Get current beneficiaries
  type BeneficiaryRow = {
    id: string;
    firstName: string;
    lastName: string;
    relationship: string | null;
    email: string | null;
    phone: string | null;
    dateOfBirth: Date | null;
  };

  const beneficiaries = await queryRaw<BeneficiaryRow>(`
    SELECT 
      id, "firstName", "lastName", relationship, email, phone, "dateOfBirth"
    FROM beneficiaries
    WHERE "clientId" = $1
    ORDER BY "createdAt" DESC
  `, [clientId]);

  // Get version history count
  type VersionCountRow = {
    count: number;
  };

  const versionCount = await queryRaw<VersionCountRow>(`
    SELECT COUNT(*)::int as count
    FROM client_versions
    WHERE "clientId" = $1
  `, [clientId]);

  const versionNumber = (versionCount && versionCount.length > 0 && versionCount[0] ? versionCount[0].count : 0) + 1;

  return (
    <main className="min-h-screen bg-paper-50 py-6 sm:py-12 overflow-x-hidden">
      <div className="mx-auto w-full max-w-4xl px-4 sm:px-6">
        <div className="mb-8 flex items-center justify-between">
          <Logo size="xl" showTagline={false} className="flex-row" href="/" />
          <Link
            href="/"
            className="text-sm font-medium text-slateui-600 hover:text-ink-900 transition"
          >
            Back to Home
          </Link>
        </div>

        <div className="card p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gold-100">
              <QrCode className="h-6 w-6 text-gold-600" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-ink-900">
                Update Your Information
              </h1>
              <p className="text-sm text-slateui-600">
                Submit changes or corrections to your policy information
              </p>
            </div>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <strong>Version {versionNumber}:</strong> This update will create a new version entry,
              preserving your complete history. Your previous information will remain accessible for reference.
            </p>
          </div>
        </div>

        <QRUpdateForm
          token={token}
          clientId={clientId}
          currentData={{
            client: {
              firstName: client.firstName,
              lastName: client.lastName,
              email: client.email,
              phone: client.phone || "",
              dateOfBirth: client.dateOfBirth 
                ? new Date(client.dateOfBirth).toISOString().split("T")[0] 
                : "",
              addressLine1: client.address_line1 || "",
              addressLine2: client.address_line2 || "",
              city: client.city || "",
              state: client.state || "",
              postalCode: client.postal_code || "",
              country: client.country || "",
            },
            policies: policies.map((p: { id: string, policy_number: string | null; policy_type: string | null; insurer_name: string }) => ({
              id: p.id,
              policyNumber: p.policy_number || "",
              policyType: p.policy_type || "",
              insurerName: p.insurer_name,
            })),
            beneficiaries: beneficiaries.map((b: { id: string, firstName: string, lastName: string, relationship: string | null; email: string | null; phone: string | null; dateOfBirth: Date | null }) => ({
              id: b.id,
              firstName: b.firstName,
              lastName: b.lastName,
              relationship: b.relationship || "",
              email: b.email || "",
              phone: b.phone || "",
              dateOfBirth: b.dateOfBirth 
                ? new Date(b.dateOfBirth).toISOString().split("T")[0] 
                : "",
            })),
          }}
        />
      </div>
    </main>
  );
}

