import Link from "next/link";
import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="border-t border-hv-border bg-hv-bg py-16 md:py-20">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4 lg:gap-10">
          <div>
            <Logo size="sm" showTagline={false} className="mb-5 flex-row" />
            <p className="text-sm leading-relaxed text-hv-text-secondary">
              HeirVault — a private, voluntary registry for life insurance policies and beneficiaries.
            </p>
          </div>

          <div>
            <h3 className="font-display text-xs font-semibold uppercase tracking-[0.14em] text-hv-text-muted">Legal</h3>
            <ul className="mt-5 space-y-2">
              <li>
                <Link href="/legal/terms" className="text-sm text-hv-text-secondary transition hover:text-hv-text">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/legal/privacy" className="text-sm text-hv-text-secondary transition hover:text-hv-text">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/legal/disclaimers" className="text-sm text-hv-text-secondary transition hover:text-hv-text">
                  Legal Disclaimers
                </Link>
              </li>
              <li>
                <Link
                  href="/legal/information-release"
                  className="text-sm text-hv-text-secondary transition hover:text-hv-text"
                >
                  Information Release Policy
                </Link>
              </li>
              <li>
                <Link href="/legal/acceptable-use" className="text-sm text-hv-text-secondary transition hover:text-hv-text">
                  Acceptable Use Policy
                </Link>
              </li>
              <li>
                <Link
                  href="/legal/attorney-agreement"
                  className="text-sm text-hv-text-secondary transition hover:text-hv-text"
                >
                  Attorney Use Agreement
                </Link>
              </li>
              <li>
                <Link href="/legal/compliance" className="text-sm text-hv-text-secondary transition hover:text-hv-text">
                  Security & Compliance
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-display text-xs font-semibold uppercase tracking-[0.14em] text-hv-text-muted">Registry</h3>
            <p className="mt-5 text-sm leading-relaxed text-hv-text-secondary">
              Private, voluntary registry. Use is voluntary and not required by law. HeirVault is not affiliated with NAIC,
              MIB, or any insurer.
            </p>
          </div>

          <div>
            <h3 className="font-display text-xs font-semibold uppercase tracking-[0.14em] text-hv-text-muted">Contact</h3>
            <ul className="mt-5 space-y-2">
              <li>
                <a href="mailto:support@heirvault.com" className="text-sm text-hv-text-secondary transition hover:text-hv-text">
                  support@heirvault.com
                </a>
              </li>
              <li>
                <a href="mailto:legal@heirvault.com" className="text-sm text-hv-text-secondary transition hover:text-hv-text">
                  legal@heirvault.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 border-t border-hv-border pt-8">
          <p className="text-center text-xs leading-relaxed text-hv-text-muted">
            © {new Date().getFullYear()} HeirVault. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
