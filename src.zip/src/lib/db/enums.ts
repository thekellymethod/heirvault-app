// Enum constants for database usage
// Use these like: AuditAction.CLIENT_CREATED

export const AuditAction = {
  CLIENT_CREATED: "CLIENT_CREATED",
  CLIENT_UPDATED: "CLIENT_UPDATED",
  POLICY_CREATED: "POLICY_CREATED",
  POLICY_UPDATED: "POLICY_UPDATED",
  BENEFICIARY_CREATED: "BENEFICIARY_CREATED",
  BENEFICIARY_UPDATED: "BENEFICIARY_UPDATED",
  BENEFICIARY_DELETED: "BENEFICIARY_DELETED",
  INVITE_CREATED: "INVITE_CREATED",
  INVITE_ACCEPTED: "INVITE_ACCEPTED",
  INVITE_REACTIVATED: "INVITE_REACTIVATED",
  CLIENT_VIEWED: "CLIENT_VIEWED",
  CLIENT_SUMMARY_PDF_DOWNLOADED: "CLIENT_SUMMARY_PDF_DOWNLOADED",
  POLICY_SEARCH_PERFORMED: "POLICY_SEARCH_PERFORMED",
  GLOBAL_POLICY_SEARCH_PERFORMED: "GLOBAL_POLICY_SEARCH_PERFORMED",
  DOCUMENT_UPLOADED: "DOCUMENT_UPLOADED",
  DOCUMENT_PROCESSED: "DOCUMENT_PROCESSED",
  ATTORNEY_VERIFIED: "ATTORNEY_VERIFIED",
  API_TOKEN_CREATED: "API_TOKEN_CREATED",
  API_TOKEN_REVOKED: "API_TOKEN_REVOKED",
  API_TOKEN_ROTATED: "API_TOKEN_ROTATED",
  API_TOKEN_USED: "API_TOKEN_USED",
} as const;

export const OrgRole = {
  OWNER: "OWNER",
  ATTORNEY: "ATTORNEY",
  STAFF: "STAFF",
} as const;

export const BillingPlan = {
  FREE: "FREE",
  SOLO: "SOLO",
  SMALL_FIRM: "SMALL_FIRM",
  ENTERPRISE: "ENTERPRISE",
} as const;

export const UserRole = {
  attorney: "attorney",
} as const;

export const InviteStatus = {
  pending: "pending",
  accepted: "accepted",
  expired: "expired",
  revoked: "revoked",
} as const;

export const AccessGrantStatus = {
  ACTIVE: "ACTIVE",
  REVOKED: "REVOKED",
} as const;

export const DocumentClassificationStatus = {
  PENDING_OCR: "PENDING_OCR",
  AUTO_ACCEPTED: "AUTO_ACCEPTED",
  NEEDS_REVIEW: "NEEDS_REVIEW",
  APPROVED: "APPROVED",
  REJECTED: "REJECTED",
} as const;

export const DocumentSensitivity = {
  PUBLIC: "PUBLIC",
  CONFIDENTIAL: "CONFIDENTIAL",
  RESTRICTED: "RESTRICTED",
} as const;

export const UploaderType = {
  ATTORNEY: "ATTORNEY",
  POLICYHOLDER: "POLICYHOLDER",
  SYSTEM: "SYSTEM",
} as const;

export const ClientInviteStatus = {
  PENDING: "PENDING",
  ACCEPTED: "ACCEPTED",
  EXPIRED: "EXPIRED",
  REVOKED: "REVOKED",
} as const;

export const DocumentCategory = {
  AUTHORITY: "AUTHORITY",
  OWNERSHIP: "OWNERSHIP",
  LIQUIDITY: "LIQUIDITY",
  CONTINUITY: "CONTINUITY",
  INTENT: "INTENT",
  OTHER: "OTHER",
} as const;

export const ChangeRequestType = {
  ADD_POLICY: "ADD_POLICY",
  UPDATE_POLICY: "UPDATE_POLICY",
  REMOVE_POLICY: "REMOVE_POLICY",
  ADD_BENEFICIARY: "ADD_BENEFICIARY",
  UPDATE_BENEFICIARY: "UPDATE_BENEFICIARY",
  REMOVE_BENEFICIARY: "REMOVE_BENEFICIARY",
  UPDATE_CLIENT_INFO: "UPDATE_CLIENT_INFO",
  // Additional change request types referenced in code
  ID_UPDATE: "ID_UPDATE",
  POLICY_UPDATE: "POLICY_UPDATE",
  BENEFICIARY_UPDATE: "BENEFICIARY_UPDATE",
  TAX_UPDATE: "TAX_UPDATE",
  ADDRESS_UPDATE: "ADDRESS_UPDATE",
} as const;

// Export the type derived from the const object
export type ChangeRequestType = typeof ChangeRequestType[keyof typeof ChangeRequestType];

export const ChangeRequestStatus = {
  SUBMITTED: "SUBMITTED",
  NEEDS_REVIEW: "NEEDS_REVIEW",
  APPROVED: "APPROVED",
  REJECTED: "REJECTED",
} as const;

export const ArtifactType = {
  BILLING_INVOICE_PDF: "BILLING_INVOICE_PDF",
  CLIENT_INVITE_PDF: "CLIENT_INVITE_PDF",
} as const;

// Note: Type exports are handled in index.ts
// This file exports the enum value constants

